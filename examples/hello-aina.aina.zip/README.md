# 问候生成器 AINA

这是一个最小的 managed AINA 示例，根据姓名生成中文或英文问候语。

示例输入：

```json
{"name": "小明", "language": "zh"}
```

示例输出：

```text
你好，小明！欢迎使用 Unibot。
```

当前平台会校验并保存项目 ZIP；接入 managed 运行器并完成部署后，Unibot 才能实际调用该入口。
